param (
    [Parameter(Mandatory=$true)]
    [string]$rootPath
)

Function Convert-BytesToSize
{
<#
.SYNOPSIS
Converts any integer size given to a user friendly size.
.DESCRIPTION


Converts any integer size given to a user friendly size.

.PARAMETER size


Used to convert into a more readable format.
Required Parameter

.EXAMPLE


ConvertSize -size 134217728
Converts size to show 128MB

#>


#Requires -version 2.0


[CmdletBinding()]
Param
(
[parameter(Mandatory=$False,Position=0)][int64]$Size

)


    #Decide what is the type of size
    Switch ($Size)
    {
        {$Size -gt 1PB}
        {
            Write-Verbose �Convert to PB�
            $NewSize = �$([math]::Round(($Size / 1PB),2)) P�
            Break
        }
        {$Size -gt 1TB}
        {
            Write-Verbose �Convert to TB�
            $NewSize = �$([math]::Round(($Size / 1TB),2)) T�
            Break
        }
        {$Size -gt 1GB}
        {
            Write-Verbose �Convert to GB�
            $NewSize = �$([math]::Round(($Size / 1GB),2)) G�
            Break
        }
        {$Size -gt 1MB}
        {
            Write-Verbose �Convert to MB�
            $NewSize = �$([math]::Round(($Size / 1MB),2)) M�
            Break
        }
        {$Size -gt 1KB}
        {
            Write-Verbose �Convert to KB�
            $NewSize = �$([math]::Round(($Size / 1KB),2)) K�
            Break
        }
        Default
        {
            Write-Verbose �Convert to Bytes�
            $NewSize = �$([math]::Round($Size,2))�
            Break
        }
    }
    Return $NewSize

}

$drives = @([IO.DriveInfo]::GetDrives() | ? { $_.DriveType -eq [IO.DriveType]::Removable })

if ($drives.Length -eq 0) {
    echo 'You must have at least one USB drive inserted to use this script.'
    exit 2
} elseif ($drives.Length -eq 1) {
    $drive = $drives[0]
} else {
    $caption = "First, choose a USB drive to become the password reset disk."
    $message = "Which drive do you want to choose?"
    $choices = [management.automation.host.choicedescription[]](
        $drives | % {
        new-object management.automation.host.choicedescription (
            "&{0} {1}" -f ($_.Name, $_.VolumeLabel)
        )}
    )
    $answer = $host.ui.PromptForChoice($caption, $message, $choices, -1)
    if ($answer -eq -1) {
        exit 2
    }
    $drive = $drives[$answer]
}

$caption = ("THE DRIVE {0} (size {1}, label '{2}')`nWILL PERMANENTLY LOSE ALL DATA." -f `
    $drive.Name,(Convert-BytesToSize $drive.TotalSize),$drive.VolumeLabel)
$message = "Is this OK?"
$choices = [management.automation.host.choicedescription[]](
    'Yes','No' | % { new-object management.automation.host.choicedescription('&' + $_) }
)
$answer = $host.ui.PromptForChoice($caption, $message, $choices, 1)
if ($answer -eq 1) {
    exit 2
}

echo "Now resetting the drive $drive"

$script = [io.path]::gettempfilename()
rm $script
$letter = $drive.Name[0]

echo "select volume=$letter" | out-file $script -encoding ASCII
echo "clean" | out-file $script -encoding ASCII -Append
echo "create partition primary" | out-file $script -encoding ASCII -Append
echo "format fs=fat32 label=PWDRESET quick" | out-file $script -encoding ASCII -Append
echo "active" | out-file $script -encoding ASCII -Append
echo "set id=EF" | out-file $script -encoding ASCII -Append

echo 'Wiping disk...'
diskpart /s $script

$vol = gwmi -class win32_volume -filter ("Name = '{0}\'" -f $drive.Name)
$s = '{0:X0}' -f $vol.SerialNumber
$uuid = '{0}-{1}' -f $s.SubString(0,4),$s.SubString(4)
echo "Writing data from $rootPath\drive"
robocopy /mir "$rootPath\drive" $drive.Name
echo "Volume UUID: $uuid"
echo ("APPEND initrd=/boot/core.gz quiet waitusb=5:UUID=""{0}"" tce=UUID=""{0}""`n" -f $uuid) | `
    out-file ($drive.Name + 'syslinux.cfg') -encoding ASCII -Append
& $rootPath\syslinux.exe -m -i "${letter}:"

# robocopy 
